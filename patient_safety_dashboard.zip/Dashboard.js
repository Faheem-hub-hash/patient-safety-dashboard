import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const Dashboard = () => {
  const [crf, setCrf] = useState({ patientId: "", diagnosis: "", notes: "" });
  const [safetyReports, setSafetyReports] = useState([]);
  const [newReport, setNewReport] = useState({ event: "", severity: "" });
  const [riskRegister, setRiskRegister] = useState([]);
  const [newRisk, setNewRisk] = useState({ risk: "", mitigation: "" });
  const [pdsaCycle, setPdsaCycle] = useState({ plan: "", do: "", study: "", act: "" });

  const handleCRFChange = (e) => {
    const { name, value } = e.target;
    setCrf((prev) => ({ ...prev, [name]: value }));
  };

  const handleSafetyChange = (e) => {
    const { name, value } = e.target;
    setNewReport((prev) => ({ ...prev, [name]: value }));
  };

  const handleRiskChange = (e) => {
    const { name, value } = e.target;
    setNewRisk((prev) => ({ ...prev, [name]: value }));
  };

  const handlePDSAChange = (e) => {
    const { name, value } = e.target;
    setPdsaCycle((prev) => ({ ...prev, [name]: value }));
  };

  const submitSafetyReport = () => {
    if (newReport.event && newReport.severity) {
      setSafetyReports((prev) => [...prev, newReport]);
      setNewReport({ event: "", severity: "" });
    }
  };

  const submitRisk = () => {
    if (newRisk.risk && newRisk.mitigation) {
      setRiskRegister((prev) => [...prev, newRisk]);
      setNewRisk({ risk: "", mitigation: "" });
    }
  };

  const severityChartData = ["Low", "Medium", "High"].map((level) => ({
    severity: level,
    count: safetyReports.filter((r) => r.severity === level).length,
  }));

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6">
      {/* Case Report Form */}
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Case Report Form</h2>
          <Input name="patientId" placeholder="Patient ID" value={crf.patientId} onChange={handleCRFChange} className="mb-2" />
          <Input name="diagnosis" placeholder="Diagnosis" value={crf.diagnosis} onChange={handleCRFChange} className="mb-2" />
          <Input name="notes" placeholder="Clinical Notes" value={crf.notes} onChange={handleCRFChange} />
        </CardContent>
      </Card>

      {/* Safety Reporting */}
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Safety Reporting</h2>
          <Input name="event" placeholder="Event Description" value={newReport.event} onChange={handleSafetyChange} className="mb-2" />
          <Input name="severity" placeholder="Severity (Low, Medium, High)" value={newReport.severity} onChange={handleSafetyChange} className="mb-2" />
          <Button onClick={submitSafetyReport}>Submit Report</Button>
          <ul className="mt-4 list-disc pl-4">
            {safetyReports.map((r, i) => (<li key={i}>{`${r.event} - ${r.severity}`}</li>))}
          </ul>
        </CardContent>
      </Card>

      {/* Safety Chart */}
      <Card className="col-span-1 md:col-span-2">
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Safety Event Severity Chart</h2>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={severityChartData}>
              <XAxis dataKey="severity" />
              <YAxis allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Risk Register */}
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">Risk Register</h2>
          <Input name="risk" placeholder="Risk Description" value={newRisk.risk} onChange={handleRiskChange} className="mb-2" />
          <Input name="mitigation" placeholder="Mitigation Plan" value={newRisk.mitigation} onChange={handleRiskChange} className="mb-2" />
          <Button onClick={submitRisk}>Add Risk</Button>
          <ul className="mt-4 list-disc pl-4">
            {riskRegister.map((r, i) => (<li key={i}>{`${r.risk} → ${r.mitigation}`}</li>))}
          </ul>
        </CardContent>
      </Card>

      {/* PDSA Cycle */}
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold mb-2">PDSA Cycle</h2>
          <Input name="plan" placeholder="Plan" value={pdsaCycle.plan} onChange={handlePDSAChange} className="mb-2" />
          <Input name="do" placeholder="Do" value={pdsaCycle.do} onChange={handlePDSAChange} className="mb-2" />
          <Input name="study" placeholder="Study" value={pdsaCycle.study} onChange={handlePDSAChange} className="mb-2" />
          <Input name="act" placeholder="Act" value={pdsaCycle.act} onChange={handlePDSAChange} className="mb-2" />
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
